# Jarvis-PC-Assistant-
Implemented a Desktop PC Assistant Application in Java. Used Speech Recognition API CMU Sphinx 4.0 for the conversion of Speech to Text. The Application performs various tasks based on the command given by the user. The Application can be used to browse the internet and control the PC with the help of Voice Commands.
